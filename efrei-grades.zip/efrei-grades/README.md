# EFREI-Grades — cible de lab (projet Ethical Hacking)

> ⚠️ Application **volontairement vulnérable**. À n'installer **que** sur une VM
> de lab isolée (réseau interne `labeh`, coupé d'Internet). Ne jamais exposer
> sur Internet ni sur un vrai réseau. Cadre pédagogique uniquement.

Portail de notes fictif. Sert de cible pour le scénario : un étudiant récupère
les identifiants de l'admin (phishing / fuite), se connecte, atteint la table
`notes` et modifie sa note.

## Failles volontaires (à exploiter puis à corriger dans le rapport)

1. **Injection SQL** sur le formulaire de connexion (`login.php`) : la requête
   concatène directement les champs → contournement d'authentification.
2. **Mot de passe admin faible et en clair** dans la base (`admin` / `Efrei2024`).
3. **Pas de contrôle d'accès** sur la page d'édition des notes (`edit.php`) :
   quiconque est connecté peut modifier n'importe quelle note.
4. **Aucune journalisation** des modifications de notes.
5. **Mots de passe stockés en clair** dans la table `users` (pas de hachage).

Chacune a sa remédiation dans le fichier `REMEDIATION.md`.

## Pile technique

PHP + MySQL/MariaDB + serveur Apache. Deux façons de lancer : Docker (simple)
ou installation manuelle.

## Installation (VM cible, carte réseau temporairement en NAT pour avoir Internet)

### Option 1 — Docker (recommandé)

```bash
sudo apt update
sudo apt install -y docker.io docker-compose
sudo systemctl start docker
cd efrei-grades
sudo docker compose up -d
```

L'appli écoute sur le port 80. Repasse ensuite la carte réseau de la VM sur
`labeh`, puis ouvre depuis l'attaquante : http://192.168.56.20

### Option 2 — Manuelle (sans Docker)

```bash
sudo apt update
sudo apt install -y apache2 php php-mysql mariadb-server
sudo systemctl start mariadb apache2
sudo mariadb < db/init.sql
sudo cp -r app/* /var/www/html/
sudo systemctl restart apache2
```

## Comptes de départ

- admin / Efrei2024  (compte administrateur)
- etudiant1 / etudiant1  (compte étudiant lambda, c'est "vous")

## Remise à zéro

Pour rejouer une démo proprement :

```bash
sudo mariadb < db/init.sql     # installation manuelle
# ou, avec Docker :
sudo docker compose down -v && sudo docker compose up -d
```
