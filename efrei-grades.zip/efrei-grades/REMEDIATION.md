# EFREI-Grades — Remédiations (pour le rapport)

Pour chaque faille volontaire : ce qui ne va pas, et comment on corrige.
Le but du projet n'est pas d'exploiter, c'est de **savoir corriger**. C'est
cette partie qui rapporte le plus de points.

---

## Faille n°1 — Injection SQL sur la connexion

**Où :** `login.php`. Les champs du formulaire sont mis directement dans la
requête SQL. Un attaquant tape `admin'-- ` comme nom d'utilisateur et entre
sans mot de passe, ou `' OR '1'='1` pour se connecter comme le premier compte.

**Gravité :** critique (CVSS élevé) — contournement total de l'authentification.

**Remédiation : requête préparée (paramétrée).** Au lieu de coller le texte
dans la requête, on utilise des paramètres liés :

```php
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param('ss', $u, $p);
$stmt->execute();
$res = $stmt->get_result();
```

La base traite alors `admin'-- ` comme un simple texte, pas comme du code.

---

## Faille n°2 — Mot de passe admin faible et en clair

**Où :** table `users`. `admin` / `Efrei2024`, lisible tel quel dans la base.

**Gravité :** élevée.

**Remédiation :**
- Mots de passe forts (longs, uniques), politique imposée.
- **Double authentification** : même un mot de passe volé ne suffit plus.
- Ne jamais stocker un mot de passe utilisable : voir faille n°5.

---

## Faille n°3 — Pas de contrôle d'accès sur l'édition des notes

**Où :** `edit.php`. N'importe quel utilisateur connecté (même un étudiant)
peut modifier n'importe quelle note. C'est le cœur du scénario.

**Gravité :** critique.

**Remédiation : vérifier le rôle au début de chaque page sensible.**

```php
if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    die('Accès refusé.');
}
```

Principe du moindre privilège : chacun n'accède qu'à ce qui le concerne.

---

## Faille n°4 — Aucune journalisation des modifications

**Où :** `edit.php`. Une note changée ne laisse aucune trace, donc l'attaque
de la phase 5 (effacer ses traces) est triviale : il n'y a rien à effacer.

**Gravité :** moyenne, mais aggrave tout le reste.

**Remédiation :**
- Table `audit_log` (qui, quand, quelle note, ancienne et nouvelle valeur).
- Journaux envoyés sur un serveur séparé, en lecture seule, pour qu'un
  attaquant ne puisse pas les effacer.

```sql
CREATE TABLE audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  utilisateur VARCHAR(50), note_id INT,
  ancienne DECIMAL(4,2), nouvelle DECIMAL(4,2),
  horodatage DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## Faille n°5 — Mots de passe stockés en clair

**Où :** table `users`. Si la base fuite, tous les mots de passe sont exposés.

**Gravité :** élevée.

**Remédiation : hacher les mots de passe** (jamais les stocker en clair).

```php
// à l'inscription :
$hash = password_hash($p, PASSWORD_DEFAULT);
// à la connexion :
if (password_verify($p, $user['password'])) { /* ok */ }
```

---

## Tableau de synthèse (à recopier dans le rapport)

| # | Faille | Gravité | Remédiation |
|---|--------|---------|-------------|
| 1 | Injection SQL (login) | Critique | Requêtes préparées |
| 2 | Mot de passe admin faible | Élevée | Mots de passe forts + 2FA |
| 3 | Pas de contrôle d'accès (edit) | Critique | Vérification du rôle, moindre privilège |
| 4 | Pas de journalisation | Moyenne | Journal d'audit en lecture seule |
| 5 | Mots de passe en clair | Élevée | Hachage (password_hash) |
