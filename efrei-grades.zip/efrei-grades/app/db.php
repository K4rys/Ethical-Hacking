<?php
// Connexion à la base. Hôte "db" en Docker, "localhost" en install manuelle.
$DB_HOST = getenv('DB_HOST') ?: 'localhost';
$conn = new mysqli($DB_HOST, 'webapp', 'webapp', 'efrei_grades');
if ($conn->connect_error) {
    die('Erreur de connexion à la base : ' . $conn->connect_error);
}
session_start();
?>
