<?php require 'db.php';

// FAILLE VOLONTAIRE n°1 : injection SQL.
// Les champs du formulaire sont concaténés directement dans la requête,
// sans requête préparée. Un attaquant peut contourner l'authentification
// avec, par exemple, un nom d'utilisateur du type :  admin'--
// ou  ' OR '1'='1
// Remédiation : utiliser une requête préparée (voir REMEDIATION.md).

$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';

    $sql = "SELECT * FROM users WHERE username = '$u' AND password = '$p'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $user = $res->fetch_assoc();
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: notes.php');
        exit;
    } else {
        $erreur = "Identifiants incorrects.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>EFREI-Grades — Connexion</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f0f2f5; }
        .box { width:320px; margin:80px auto; background:#fff; padding:30px;
               border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.1); }
        h1 { color:#c8102e; font-size:20px; text-align:center; }
        input { width:100%; padding:8px; margin:6px 0; box-sizing:border-box; }
        button { width:100%; padding:10px; background:#c8102e; color:#fff;
                 border:none; border-radius:4px; cursor:pointer; }
        .err { color:#c8102e; font-size:13px; }
    </style>
</head>
<body>
    <div class="box">
        <h1>EFREI-Grades</h1>
        <p style="text-align:center;color:#666;font-size:13px;">Portail de notes</p>
        <?php if ($erreur): ?><p class="err"><?= $erreur ?></p><?php endif; ?>
        <form method="post">
            <input name="username" placeholder="Nom d'utilisateur" autofocus>
            <input name="password" type="password" placeholder="Mot de passe">
            <button type="submit">Se connecter</button>
        </form>
    </div>
</body>
</html>
