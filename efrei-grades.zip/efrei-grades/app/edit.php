<?php require 'db.php';
if (!isset($_SESSION['username'])) { header('Location: login.php'); exit; }

// FAILLE VOLONTAIRE n°3 : aucun contrôle de rôle ici.
// N'importe quel utilisateur connecté (même un étudiant) peut modifier
// n'importe quelle note, simplement en atteignant cette page.
// On devrait vérifier :  if ($_SESSION['role'] !== 'admin') { refus }
//
// FAILLE VOLONTAIRE n°4 : aucune journalisation.
// Une modification de note ne laisse aucune trace (qui, quand, quoi).
// Remédiation : les deux points sont traités dans REMEDIATION.md.

$id = $_GET['id'] ?? ($_POST['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $note = $_POST['note'];
    // Note : requête préparée ici, mais le vrai défaut est l'absence de contrôle d'accès.
    $stmt = $conn->prepare("UPDATE notes SET note = ? WHERE id = ?");
    $stmt->bind_param('di', $note, $id);
    $stmt->execute();
    header('Location: notes.php');
    exit;
}

$res = $conn->query("SELECT * FROM notes WHERE id = " . intval($id));
$n = $res->fetch_assoc();
if (!$n) { die('Note introuvable.'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>EFREI-Grades — Modifier une note</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f0f2f5; }
        .wrap { max-width:400px; margin:60px auto; background:#fff; padding:24px;
                border-radius:8px; }
        input { width:100%; padding:8px; margin:6px 0; box-sizing:border-box; }
        button { padding:10px 16px; background:#c8102e; color:#fff; border:none;
                 border-radius:4px; cursor:pointer; }
    </style>
</head>
<body>
    <div class="wrap">
        <h2>Modifier une note</h2>
        <p><?= htmlspecialchars($n['etudiant']) ?> — <?= htmlspecialchars($n['matiere']) ?></p>
        <form method="post">
            <input type="hidden" name="id" value="<?= $n['id'] ?>">
            <input name="note" type="number" step="0.01" min="0" max="20"
                   value="<?= htmlspecialchars($n['note']) ?>">
            <button type="submit">Enregistrer</button>
            <a href="notes.php">Annuler</a>
        </form>
    </div>
</body>
</html>
