<?php require 'db.php';
if (!isset($_SESSION['username'])) { header('Location: login.php'); exit; }

$res = $conn->query("SELECT * FROM notes ORDER BY etudiant, matiere");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>EFREI-Grades — Notes</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f0f2f5; margin:0; }
        header { background:#c8102e; color:#fff; padding:12px 24px; display:flex;
                 justify-content:space-between; align-items:center; }
        .wrap { max-width:700px; margin:24px auto; background:#fff; padding:24px;
                border-radius:8px; }
        table { width:100%; border-collapse:collapse; }
        th,td { padding:8px 12px; border-bottom:1px solid #eee; text-align:left; }
        th { background:#fafafa; }
        a.btn { color:#c8102e; text-decoration:none; }
        .admin { background:#fff4f4; padding:8px 12px; border-radius:4px;
                 font-size:13px; color:#c8102e; margin-bottom:12px; }
    </style>
</head>
<body>
    <header>
        <strong>EFREI-Grades</strong>
        <span><?= htmlspecialchars($_SESSION['username']) ?>
              (<?= htmlspecialchars($_SESSION['role']) ?>) —
              <a href="logout.php" style="color:#fff;">Déconnexion</a></span>
    </header>
    <div class="wrap">
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <div class="admin">Mode administrateur : vous pouvez modifier les notes.</div>
        <?php endif; ?>
        <h2>Relevé de notes</h2>
        <table>
            <tr><th>Étudiant</th><th>Matière</th><th>Note</th><th></th></tr>
            <?php while ($n = $res->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($n['etudiant']) ?></td>
                <td><?= htmlspecialchars($n['matiere']) ?></td>
                <td><?= htmlspecialchars($n['note']) ?></td>
                <td><a class="btn" href="edit.php?id=<?= $n['id'] ?>">Modifier</a></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
