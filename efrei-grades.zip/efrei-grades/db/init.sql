-- EFREI-Grades : base de données de la cible de lab
-- ⚠️ Volontairement non sécurisée (mots de passe en clair, etc.)

DROP DATABASE IF EXISTS efrei_grades;
CREATE DATABASE efrei_grades CHARACTER SET utf8mb4;
USE efrei_grades;

-- Utilisateurs. FAILLE : mots de passe stockés en clair (devraient être hachés).
CREATE TABLE users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role     VARCHAR(20) NOT NULL DEFAULT 'etudiant'
);

-- FAILLE : mot de passe admin faible et en clair.
INSERT INTO users (username, password, role) VALUES
    ('admin',      'Efrei2024',  'admin'),
    ('etudiant1',  'etudiant1',  'etudiant'),
    ('etudiant2',  'azerty',     'etudiant');

-- Notes.
CREATE TABLE notes (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    etudiant VARCHAR(50) NOT NULL,
    matiere  VARCHAR(50) NOT NULL,
    note     DECIMAL(4,2) NOT NULL
);

INSERT INTO notes (etudiant, matiere, note) VALUES
    ('etudiant1', 'Ethical Hacking', 8.00),
    ('etudiant1', 'Réseaux',         11.50),
    ('etudiant1', 'SMSI',            14.00),
    ('etudiant2', 'Ethical Hacking', 12.00),
    ('etudiant2', 'Réseaux',         9.00);

-- Compte MySQL utilisé par l'appli (droits larges = aussi une faiblesse)
-- '%' = depuis n'importe quel hôte, pour marcher en Docker ET en local.
CREATE USER IF NOT EXISTS 'webapp'@'%' IDENTIFIED BY 'webapp';
GRANT ALL PRIVILEGES ON efrei_grades.* TO 'webapp'@'%';
CREATE USER IF NOT EXISTS 'webapp'@'localhost' IDENTIFIED BY 'webapp';
GRANT ALL PRIVILEGES ON efrei_grades.* TO 'webapp'@'localhost';
FLUSH PRIVILEGES;
